//
// Created by Mina on 26.05.2020.
//

#include "testdriver.hpp"

int main() {
    Testdriver::execute_tests();
}