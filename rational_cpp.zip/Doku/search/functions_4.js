var searchData=
[
  ['format_94',['format',['../class_number_format.html#a2bef7e7b9b6af8b4a67268ea681f5194',1,'NumberFormat::format()'],['../class_number_format_d_e.html#a8bf32b24a0e90123d74f5bc7483ff5ef',1,'NumberFormatDE::format()'],['../class_number_format_e_n.html#a6b1596c012a265c07052c9701bb42215',1,'NumberFormatEN::format()']]],
  ['format_5fhelp_95',['format_help',['../class_number_format.html#a1ef141e5edd8733567e5cbae44fb495e',1,'NumberFormat']]]
];
