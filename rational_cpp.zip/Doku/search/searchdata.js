var indexSectionsWithContent =
{
  0: "_acdefgimnoprst~",
  1: "dnrt",
  2: "emnrt",
  3: "acdefgimnoprst~",
  4: "_n",
  5: "f",
  6: "eg",
  7: "o",
  8: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "related",
  8: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Friends",
  8: "Macros"
};

