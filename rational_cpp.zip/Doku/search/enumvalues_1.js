var searchData=
[
  ['german_143',['german',['../class_number_format.html#a2d25718f79b1974b8b7c6daa1a702b3caa6d414ac4f293187dd042025834925f7',1,'NumberFormat']]]
];
