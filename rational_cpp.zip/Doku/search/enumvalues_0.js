var searchData=
[
  ['english_142',['english',['../class_number_format.html#a2d25718f79b1974b8b7c6daa1a702b3caba0a6ddd94c73698a3658f92ac222f8a',1,'NumberFormat']]]
];
