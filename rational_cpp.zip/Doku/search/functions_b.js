var searchData=
[
  ['rational_116',['Rational',['../class_rational.html#a37adb08093f82b0945444d72bf4b3596',1,'Rational::Rational(long long int z=1, long long int n=1, NumberFormat *nf=nullptr)'],['../class_rational.html#ad9f49db19b1d6dd3cf307aa3b60b85d0',1,'Rational::Rational(const Rational &amp;)']]],
  ['remove_5fall_117',['remove_all',['../class_number_format.html#ac75545b8b128242a25254fdf38168f52',1,'NumberFormat']]],
  ['remove_5funnecessary_5fzeros_118',['remove_unnecessary_zeros',['../class_number_format.html#a7210d5c090725da837bcada3204ff49b',1,'NumberFormat']]],
  ['replace_5fcharacter_119',['replace_character',['../class_number_format.html#ad5bf235a341eb6a1208d9dbdc6806963',1,'NumberFormat']]]
];
